package com.college.zipkinservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
